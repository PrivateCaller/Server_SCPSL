//Integrates Support_Updater into the mod. Doesn't seem to actually work.
exec("./scripts/Support_UpdaterDownload.cs");