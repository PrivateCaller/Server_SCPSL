//No more having to push updates over Discord.
exec("./scripts/Support_UpdaterDownload.cs")