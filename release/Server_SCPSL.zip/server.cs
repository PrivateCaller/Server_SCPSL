exec("./prefs.cs");
//Import saved variables. If there aren't any or they server has an outdated version, revert to default.
if(isFile("config/server/SCPSL/variables.cs") && SCPSL_upToDate())
{
    SCPSL_readPreferencesFromFile();
}
else
{
    //If the config file doesn't exist, fallback on default variable values and recreate the file.
    $SCPSL::OFN_Team = "SCP-049";
    $SCPSL::OFN_TickTime = 500;
    $SCPSL::OZS_Team = "SCP-106";
    $SCPSL::OZS_LairVar = "106_lair_spawnpoint";
    $SCPSL::surfaceVar = "isAboveSurface";
    $SCPSL::lczVar = "isInLowContainZone";
    $SCPSL::ZombiesInfect = 1;
    $SCPSL::InfectTumble = 1;
    SCPSL_savePreferencesToFile();
}

//Sounds. Important that these are executed before everything else.
exec("./sounds/ofn_sounds.cs");

//Now for the main code.
exec("./scripts/kill_events.cs");
exec("./scripts/ozs_teleport.cs");
exec("./scripts/ofn_zombify.cs");

//Playertypes.