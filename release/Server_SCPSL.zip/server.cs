if($version__Server_SCPSL !$= "")
{
    $SCPSL::version = $version__Server_SCPSL;
}
else
{
    $SCPSL::version = "0.8.0";
}
exec("./scripts/prefs.cs");
//Import saved variables. If there aren't any or they server has an outdated version, revert to default.
if(isFile("config/server/SCPSL/variables.cs") && SCPSL_upToDate())
{
    SCPSL_readPreferencesFromFile();
}
else
{
    //If the config file doesn't exist, fallback on default variable values and recreate the file.
    $SCPSL::OFN_Team = "SCP-049";
    $SCPSL::OFN_TickTime = 4000;
    $SCPSL::OZS_Team = "SCP-106";
    $SCPSL::OZS_LairVar = "106_lair_spawnpoint";
    $SCPSL::OZS_TickTime = 5000;
    $SCPSL::surfaceVar = "isAboveSurface";
    $SCPSL::lczVar = "isInLowContainZone";
    $SCPSL::ZombiesInfect = 1;
    $SCPSL::InfectTumble = 1;
    SCPSL_savePreferencesToFile();
}

exec("./scripts/general.cs");

//Events.
exec("./scripts/kill_events.cs");

//SCP-049 stuff.
exec("./playertypes/ofn/ofn_sounds.cs");
exec("./scripts/ofn_zombify.cs");
exec("./playertypes/ofn/ofn_playertype.cs");

//SCP-106 stuff.
exec("./playertypes/ozs/ozs_sounds.cs");
exec("./scripts/ozs_tar.cs");
exec("./scripts/ozs_kidnap.cs");
exec("./playertypes/ozs/ozs_playertype.cs");