datablock AudioProfile(CIV_OutOfBreath)
{
	fileName = "./sounds/CIV_OutOfBreath.wav";
	description = AudioClosest3d;
	preload = 0;
};
datablock AudioProfile(CIV_Breath1 : CIV_OutOfBreath)
{
	filename = "./sounds/CIV_Breath1.wav";
};
datablock AudioProfile(CIV_Breath2 : CIV_OutOfBreath)
{
	filename = "./sounds/CIV_Breath2.wav";
};
datablock AudioProfile(CIV_Breath3 : CIV_OutOfBreath)
{
	filename = "./sounds/CIV_Breath3.wav";
};
datablock AudioProfile(CIV_Cough1 : CIV_OutOfBreath)
{
	filename = "./sounds/CIV_Cough1.wav";
};
datablock AudioProfile(CIV_Cough2 : CIV_OutOfBreath)
{
	filename = "./sounds/CIV_Cough2.wav";
};
datablock AudioProfile(CIV_Cough3 : CIV_OutOfBreath)
{
	filename = "./sounds/CIV_Cough3.wav";
};