//Largely copied from Clockturn's Sprinting playertype: https://blocklandglass.com/addons/rtb/view.php?id=2640

function CIV_runLoop(%miller)
{
	if(%miller.getState() $= "Dead" || %miller.getDatablock().getName() !$= "SprintingCivillianPlayerArmor")
    {
        return;
    }

	if(%miller.getEnergyLevel() <= 1)
	{
		SCPSL_speak(%miller, CIV_OutOfBreath, 200, 0);
		%miller.changeDatablock("CivillianPlayerArmor");
		return;
	}
	else if(%miller.getEnergyLevel() <= 75 && !SCPSL_isSpeaking(%miller))
	{
		SCPSL_speak(%miller, SCPSL_getRandomSound("CIV_Breath", 3), 0, 0);
	}
	%miller.client.CIV_runSchedule = schedule(%miller.getEnergyLevel()*4.0625, %miller.getID(), "CIV_runLoop", %miller);
}

//
// Main playertype.
//

datablock PlayerData(CivillianPlayerArmor : PlayerStandardArmor)
{
	rechargeRate = 0.05;
	canJet = 0;

	uiName = "Personnel Player";

	canRide = 1;
	showEnergyBar = 1;
};
function CivillianPlayerArmor::onNewDataBlock(%this, %miller)
{
	if(isEventPending(%miller.client.CIV_runSchedule))
	{
		cancel(%miller.client.CIV_runSchedule); //We're no longer running, stop the breathing loop.
	}
    parent::onNewDataBlock(%this, %miller);
}
function CivillianPlayerArmor::onTrigger(%this, %miller, %trigger, %val)
{
	if(%trigger == 4 && %val == 1) //They're right-clicking, start sprinting.
	{
		%miller.setDataBlock("SprintingCivillianPlayerArmor");
	}
	parent::onTrigger(%this, %miller, %trigger, %val);
}

//
// Hidden playertype for sprinting.
//

datablock PlayerData(SprintingCivillianPlayerArmor : CivillianPlayerArmor)
{
	runEnergyDrain = 0.75;
	minRunEnergy = 0;
	maxForwardSpeed = "12";
	maxBackwardSpeed = "0";
	maxSideSpeed = "0";

	maxForwardCrouchSpeed = "3";
	maxBackwardCrouchSpeed = "2";
	maxSideCrouchSpeed = "2";
	airControl = 0;

	uiName = "";
	canRide = 0;
};
function SprintingCivillianPlayerArmor::onNewDataBlock(%this, %miller)
{
	CIV_runLoop(%miller); //We've now running, start the breathing loop.
    parent::onNewDataBlock(%this, %miller);
}
function SprintingCivillianPlayerArmor::onTrigger(%this, %miller, %trigger, %val)
{
	if(%trigger == 4 && %val == 0) //They let up off the right mouse button, stop sprinting.
	{
		cancel(%miller.client.CIV_runSchedule);
		%miller.setDataBlock("CivillianPlayerArmor");
	}
	parent::onTrigger(%this, %miller, %trigger, %val);
}