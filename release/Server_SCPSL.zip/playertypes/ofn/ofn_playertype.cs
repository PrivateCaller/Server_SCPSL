//
// Supporting functions.
//

function OFN_getQuip(%type)
{
    if(%type $= "Chase")
    {
        return NameToID("OFN_Spotted" @ getRandom(1, 7));
    }
    if(%type $= "Search")
    {
        return NameToID("OFN_Search" @ getRandom(1, 7));
    }
}

function OFN_speak(%doctor, %voiceLine)
{
    %doctor.stopAudio(2);
    %doctor.playAudio(2, %voiceLine);
    %doctor.voiceLinePlayed = "" @ %voiceLine;
    %doctor.willFinishSpeaking = (getSimTime() + (SCPSL_estimateSoundDuration(%voiceLine) + 5000));
}

function OFN_isSpeaking(%doctor)
{
    if(%doctor.voiceLinePlayed $= "OFN_Breath")
    {
        return 0;
    }
    else if(getSimTime() > %doctor.willFinishSpeaking)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

function OFN_loop(%doctor)
{
    if(%doctor.getState() $= "Dead")
    {
        return;
    }
    //Check if any players are around.
    initContainerRadiusSearch(%doctor.getPosition(), 64, $TypeMasks::PlayerObjectType);
    while((%target = containerSearchNext()) != 0)
    {
        //Mark if enemy players are around and whether or not we're looking at them.
	    %target = %target.getID();
        if(%target != %doctor && !isAlliedTeam(%target.getTeam()))
        {
            %nearby = true;
            %spotted = SCPSL_isInFOV(%doctor, %target);
            break;
        }
    }
    if(!%spotted && %nearby && !OFN_isSpeaking(%doctor))
    {
        //There are player(s) nearby but we can't see them, so ask them to show themselves.
        if(getRandom(1,4) == 1)
        {
            OFN_speak(%doctor, OFN_getQuip("Search"));
        }
    }
    else if(%spotted && !OFN_isSpeaking(%doctor))
    {
        //There are player(s) nearby and we can see them, so tell them they're sick and raise the doctor's arm.
        OFN_speak(%doctor, OFN_getQuip("Chase"));
        %doctor.playThread(0,"armReadyRight");
    }
    else if(!OFN_isSpeaking(%doctor) && %doctor.voiceLinePlayed !$= "OFN_Breath")
    {
        //Nobody's nearby, just breath and lower the arm.
        OFN_speak(%doctor, OFN_Breath);
        %doctor.playThread(0,"root");
    }
    %doctor.client.OFN_schedule = schedule($SCPSL::OFN_TickTime, %doctor.getID(), "OFN_loop", %doctor);
}

//
// Hats
//

// Plague mask, ripped from Mr. Nobody's hat pack.
datablock ShapeBaseImageData(PlagueMaskHatImage)
{
   shapeFile = "./mask/Blight.dts";
   emap = true;
   mountPoint = $HeadSlot;
   offset = "0 0.1 -0.1";
   eyeOffset = "0 0 -1000";
   rotation = eulerToMatrix("0 0 0");
   scale = "1 1 1";
   doColorShift = true;
   colorShiftColor = "0.000 0.500 0.250 1.000";
};
//His hood, ripped from Mr. Nobody's 3rd hat pack.
datablock ShapeBaseImageData(PlagueHoodHatImage)
{
   shapeFile = "./hood/RHood.dts";
   emap = true;
   mountPoint = $HeadSlot;
   offset = "0 0 0";
   eyeOffset = "0 0 -1000";
   rotation = eulerToMatrix("0 0 0");
   scale = "1.2 1.2 1.2";
   doColorShift = true;
   colorShiftColor = "0.000 0.500 0.250 1.000";
};

//
// Main playertype.
//

datablock PlayerData(PlagueDoctorArmor : PlayerStandardArmor)
{
    maxForwardSpeed = 7;
	maxBackwardSpeed = 7;
    maxSideSpeed = 7;
    maxDamage = 750;
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
    isSCP = true;

	uiName = "SCP-049";
	showEnergyBar = false;
};

function PlagueDoctorArmor::onAdd(%this, %doctor)
{
    if(%this.getClassName() == "PlagueDoctorArmor")
    {
        //Mount the doctor's hats. Needs to be used alongside Slayer's team uniform system to look right.
        %doctor.mountImage(PlagueHoodHatImage, 2); //Give him a better looking hood than the default.
        %doctor.mountImage(PlagueMaskHatImage, 1); //Give him his iconic mask.
        //Finally, start 049's fancy loop only if he's in a minigame.
        %minigame = getMiniGameFromObject(%doctor);
        if(isSlayerMinigame(%minigame) && %minigame.Teams.getCount() > 1)
        {
            OFN_loop(%doctor);
        }
    }
    parent::onAdd(%this, %doctor);
}

function PlagueDoctorArmor::onRemove(%this, %doctor)
{
    if(%this.getClassName() == "PlagueDoctorArmor")
    {
        //Make the doctor stop speaking if he dies.
        %doctor.stopAudio(2);
        cancel(%doctor.client.OFN_schedule);
    }
    parent::onRemove(%this, %doctor);
}