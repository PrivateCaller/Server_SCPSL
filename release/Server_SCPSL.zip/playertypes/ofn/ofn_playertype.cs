//
// Supporting functions.
//

function OFN_getQuip(%type)
{
    if(%type $= "Chase")
    {
        return NameToID("OFN_Spotted" @ getRandom(1, 7));
    }
    if(%type $= "Search")
    {
        return NameToID("OFN_Search" @ getRandom(1, 7));
    }
}

function OFN_loop(%doctor)
{
    if(%doctor.getState() $= "Dead" || %doctor.getDatablock().getName() !$= "PlagueDoctorArmor")
    {
        return;
    }
    //Getting the doctor's team changes depending on if it's a bot or a human.
    if(%doctor.getClassName() $= "AIPlayer") 
    {
        %doctor_team = %doctor.getDatablock().hType; //If the doctor is a bot, get his hType.
    }
    else
    {
        %doctor_team = %doctor.client.getTeam(); //If the doctor is a human, use "getTeam()"
    }
    //Check if any players are around.
    initContainerRadiusSearch(%doctor.getPosition(), 64, $TypeMasks::PlayerObjectType);
    while((%target = containerSearchNext()) != 0)
    {
        ////Mark if enemy players are around and whether or not we're looking at them.
	    %target = %target.getID();
        //Get the target's team.
        if(%target.getClassName() $= "AIPlayer") 
        {
            %target_team = %target.getDatablock().hType; //If the doctor is a bot, get his hType.
        }
        else
        {
            %target_team = %target.client.getTeam(); //If the doctor is a human, use "getTeam()"
        }
        //Make sure they're not allied with the doctor.
        if(%target != %doctor && !SCPSL_isAlliedTeam(getMiniGameFromObject(%doctor), %doctor_team, %target_team))
        {
            %nearby = true;
            %spotted = SCPSL_isInFOV(%doctor, %target);
            break;
        }
    }
    //Sneaking: If the doctor isn't moving or is crouched, don't play voice lines and only breathe.
    if(!%spotted && %nearby && !SCPSL_isSpeaking(%doctor) && !%doctor.isCrouched() && %doctor.getVelocity() !$= "0 0 0")
    {
        //There are player(s) nearby but we can't see them, so ask them to show themselves.
        if(getRandom(1,4) == 1)
        {
            SCPSL_speak(%doctor, OFN_getQuip("Search"), 5000, 0);
        }
    }
    else if(%spotted && !SCPSL_isSpeaking(%doctor) && !%doctor.isCrouched() && %doctor.getVelocity() !$= "0 0 0")
    {
        //There are player(s) nearby and we can see them, so tell them they're sick and raise the doctor's arm.
        SCPSL_speak(%doctor, OFN_getQuip("Chase"), 5000, 0);
        if(!%doctor.armUp == 1)
        {
            %doctor.playThread(0, armReadyRight);
            %doctor.armUp = 1;
        }
    }
    else if(!SCPSL_isSpeaking(%doctor) && %doctor.voiceLinePlayed !$= "OFN_Breath")
    {
        //Nobody's nearby, just breath and lower the arm.
        SCPSL_speak(%doctor, OFN_Breath, 0, 1);
        if(!%doctor.armUp == 0)
        {
            %doctor.playThread(0, root);
            %doctor.armUp = 0;
        }
    }
    %doctor.client.OFN_schedule = schedule($SCPSL::OFN_TickTime, %doctor.getID(), "OFN_loop", %doctor);
}

//
// His hat (a hood and plague mask.)
//

datablock ShapeBaseImageData(PlagueDoctorHatImage)
{
   shapeFile = "./hat/OFN_head.dts";
   emap = true;
   mountPoint = $HeadSlot;
   offset = "0 0 0";
   eyeOffset = "0 0 -1000";
   rotation = eulerToMatrix("0 0 0");
   scale = "1 1 1";
   doColorShift = true;
   colorShiftColor = "0.000 0.500 0.250 1.000";
};

//
// Main playertype.
//

datablock PlayerData(PlagueDoctorArmor : PlayerStandardArmor)
{
    maxForwardSpeed = 8;
	maxBackwardSpeed = 7;
    maxSideSpeed = 7;
    maxDamage = 750;
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
    isSCP = true;

	uiName = "SCP-049";
	showEnergyBar = false;
};

function PlagueDoctorArmor::onAdd(%this, %doctor)
{
    if(%this.getName() $= "PlagueDoctorArmor")
    {
        //Needs to be used alongside Slayer's team uniform system to look right.
        %doctor.mountImage(PlagueDoctorHatImage, 2); //Give him a hood and his iconic mask.
        //Finally, start 049's fancy loop only if he's in a minigame.
        %minigame = getMiniGameFromObject(%doctor);
        if(isSlayerMinigame(%minigame) && %minigame.Teams.getCount() > 1)
        {
            OFN_loop(%doctor);
        }
    }
    parent::onAdd(%this, %doctor);
}

function PlagueDoctorArmor::onNewDataBlock(%this, %doctor)
{
    if(%this.getName() $= "PlagueDoctorArmor")
    {
        %doctor.mountImage(PlagueDoctorHatImage, 2);
        %minigame = getMiniGameFromObject(%doctor);
        if(isSlayerMinigame(%minigame) && %minigame.Teams.getCount() > 1)
        {
            OFN_loop(%doctor);
        }
    }
    parent::onNewDataBlock(%this, %doctor);
}

function PlagueDoctorArmor::onDisabled(%this, %doctor)
{
    if(%this.getName() $= "PlagueDoctorArmor")
    {
        //Make the doctor stop speaking if he dies.
        %doctor.stopAudio(2);
        cancel(%doctor.client.OFN_schedule);
    }
    parent::onDisabled(%this, %doctor);
}
