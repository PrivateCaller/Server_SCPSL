//
// Supporting functions.
//

//Ripped from Rotondo's holebot "hFOVCheck" function, then minimized into oblivian for speed purposes. Last function was slow.
function SCPSL_isInFOV( %player, %target)
{	
	return vectorDot(%doctor.getEyeVector(), vectorNormalize(vectorSub(%target.getPosition(), %doctor.getPosition()))) >= 0.7;
}

function SCPSL_estimateSoundDuration(%sound)
{
    //All of the sounds used in this mod are 8-bit 22050Hz Mono sounds, so estimating their length based on file size is actually feisible.
    //Returns duration in miliseconds.
    return getFileLength(%sound.filename) / 22.05;
}

//
// Playertype functions.
//

function OFN_getQuip(%type)
{
    talk("Getting quip...");
    if(%type $= "Chase")
    {
        return NameToID("OFN_Spotted" @ getRandom(1, 7));
    }
    if(%type $= "Search")
    {
        return NameToID("OFN_Search" @ getRandom(1, 7));
    }
}

function OFN_speak(%doctor, %voiceLine)
{
    %doctor.stopAudio(2);
    %doctor.playAudio(2, %voiceLine);
    %doctor.voiceLinePlayed = "" @ %voiceLine;
    %doctor.willFinishSpeaking = (getSimTime() + (SCPSL_estimateSoundDuration(%voiceLine) + 5000));
}

function OFN_isSpeaking(%doctor)
{
    if(%doctor.voiceLinePlayed $= "OFN_Breath")
    {
        return 0;
    }
    else if(getSimTime() > %doctor.willFinishSpeaking)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}

function OFN_loop(%doctor)
{
    if(%doctor.getState() $= "Dead")
    {
        return;
    }
    //Step 1, check if any players are around.
    initContainerRadiusSearch(%doctor.getPosition(), 64, $TypeMasks::PlayerObjectType);
    while((%target = containerSearchNext()) != 0)
    {
        //If we have targets and are looking at them, mark a variable as such.
	    %target = %target.getID();
        if(%target != %doctor && !isAlliedTeam(%target.getTeam()))
        {
            %nearby = true;
            %spotted = SCPSL_isInFOV(%doctor, %target);
            break;
        }
    }
    if(!%spotted && %nearby && !OFN_isSpeaking(%doctor))
    {
        if(getRandom(1,4) == 1)
        {
            OFN_speak(%doctor, OFN_getQuip("Search"));
        }
    }
    else if(%spotted && !OFN_isSpeaking(%doctor))
    {
        OFN_speak(%doctor, OFN_getQuip("Chase"));
        %doctor.playThread(0,"armReadyRight");
    }
    else if(!OFN_isSpeaking(%doctor) && %doctor.voiceLinePlayed !$= "OFN_Breath")
    {
        OFN_speak(%doctor, OFN_Breath);
        %doctor.playThread(0,"root");
    }
    %doctor.client.OFN_schedule = schedule($SCPSL::OFN_TickTime, %doctor.getID(), "OFN_loop", %doctor);
}

//
// Hats
//

// Plague mask, ripped from Mr. Nobody's hat pack.
datablock ShapeBaseImageData(PlagueMaskHatImage)
{
   shapeFile = "./mask/Blight.dts";
   emap = true;
   mountPoint = $HeadSlot;
   offset = "0 0.1 -0.1";
   eyeOffset = "0 0 -1000";
   rotation = eulerToMatrix("0 0 0");
   scale = "1 1 1";
   doColorShift = true;
   colorShiftColor = "0.000 0.500 0.250 1.000";
};
//His hood, ripped from Mr. Nobody's 3rd hat pack.
datablock ShapeBaseImageData(PlagueHoodHatImage)
{
   shapeFile = "./hood/RHood.dts";
   emap = true;
   mountPoint = $HeadSlot;
   offset = "0 0 0";
   eyeOffset = "0 0 -1000";
   rotation = eulerToMatrix("0 0 0");
   scale = "1.2 1.2 1.2";
   doColorShift = true;
   colorShiftColor = "0.000 0.500 0.250 1.000";
};

//
// Main playertype.
//

datablock PlayerData(PlagueDoctorArmor : PlayerStandardArmor)
{
    maxForwardSpeed = 7;
	maxBackwardSpeed = 7;
    maxSideSpeed = 7;
    maxDamage = 750;
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
    isSCP = true;

	uiName = "SCP-049";
	showEnergyBar = false;
};

function PlagueDoctorArmor::onAdd(%this, %doctor)
{
    //First, remove any other hats the doctor might have on.
    %doctor.hideNode(helmet);
    %doctor.hideNode(pointyHelmet);
    %doctor.hideNode(flareHelmet);
    %doctor.hideNode(scoutHat);
    %doctor.hideNode(bicorn);
    %doctor.hideNode(copHat);
    %doctor.hideNode(knitHat);
    //Then, mount his actually good hats.
    %doctor.mountImage(PlagueHoodHatImage, 2); //Give him a better looking hood than the default.
    %doctor.mountImage(PlagueMaskHatImage, 1); //Give him his iconic mask.
    //Finally, start 049's fancy loop if he's in a minigame.
    %minigame = getMiniGameFromObject(%doctor);
    if(isSlayerMinigame(%minigame) && %minigame.Teams.getCount() > 1)
    {
        OFN_loop(%doctor);
    }
}

function PlagueDoctorArmor::onRemove(%this, %doctor)
{
    //Make the doctor stop speaking if he dies.
    %doctor.stopAudio(2);
    cancel(%doctor.client.OFN_schedule);
}