function OZS_loop(%oldie)
{
    if(%oldie.getState() $= "Dead" || %oldie.getDatablock().getName() !$= "RadicalLarryArmor")
    {
        return;
    }
    //Check if any players are around.
    initContainerRadiusSearch(%oldie.getPosition(), 64, $TypeMasks::PlayerObjectType);
    while((%target = containerSearchNext()) != 0)
    {
        //Mark if enemy players are around and whether or not we're looking at them.
	    %target = %target.getID();
        if(%target != %oldie && !%oldie.client.getTeam().isAlliedTeam(%target.client.getTeam()))
        {
            %nearby = true;
            %spotted = SCPSL_isInFOV(%oldie, %target);
            break;
        }
    }
    //Sneaking: If the oldie isn't moving or is crouched, don't play voice lines and only breathe.
    if((%spotted || %nearby) && !SCPSL_isSpeaking(%oldie) && !%oldie.isCrouched() && %oldie.getVelocity() !$= "0 0 0")
    {
        SCPSL_speak(%oldie, OZS_BreathChase, 2000, 0);
    }
    else if(!SCPSL_isSpeaking(%oldie) && %oldie.voiceLinePlayed !$= "OFN_BreathSearch")
    {
        SCPSL_speak(%oldie, OZS_BreathSearch, 3000, 1);
    }
    %oldie.client.OZS_schedule = schedule($SCPSL::OZS_TickTime, %oldie.getID(), "OZS_loop", %oldie);
}

//
// Main playertype.
//

datablock PlayerData(RadicalLarryArmor : PlayerStandardArmor)
{
    maxForwardSpeed = 8;
	maxBackwardSpeed = 7;
    maxSideSpeed = 7;
    maxDamage = 750;
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
    isSCP = true;

	uiName = "SCP-106";
	showEnergyBar = false;
};

function RadicalLarryArmor::onAdd(%this, %oldie)
{
    if(%this.getName() $= "RadicalLarryArmor")
    {
        //Needs to be used alongside Slayer's team uniform system to look right.
        //Only start the fancy loop if he's in a minigame.
        %minigame = getMiniGameFromObject(%oldie);
        if(isSlayerMinigame(%minigame) && %minigame.Teams.getCount() > 1)
        {
            OZS_loop(%oldie);
        }
    }
    parent::onAdd(%this, %oldie);
}

function RadicalLarryArmor::onNewDataBlock(%this, %oldie)
{
    if(%this.getName() $= "RadicalLarryArmor")
    {
        %minigame = getMiniGameFromObject(%oldie);
        if(isSlayerMinigame(%minigame) && %minigame.Teams.getCount() > 1)
        {
            OFN_loop(%oldie);
        }
    }
    parent::onNewDataBlock(%this, %oldie);
}

function RadicalLarryArmor::onDisabled(%this, %oldie)
{
    if(%this.getName() $= "RadicalLarryArmor")
    {
        //Make Radical Larry stop breathing if he dies.
        %oldie.stopAudio(2);
        cancel(%oldie.client.OZS_schedule);
    }
    parent::onDisabled(%this, %oldie);
}

function RadicalLarryArmor::onRemove(%this, %oldie)
{
    ServerPlay3D(SCPSL_getRandomSound(3, 6), %oldie.getPosition());
    %oldie.spawnExplosion(ozsTarProjectile, 1.0);
    schedule(500, %oldie, "delete");
}
