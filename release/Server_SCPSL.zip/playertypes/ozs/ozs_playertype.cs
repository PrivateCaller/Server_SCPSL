function OZS_loop(%oldie)
{
    if(%oldie.getState() $= "Dead" || %oldie.getDatablock().getName() !$= "RadicalLarryArmor")
    {
        return;
    }
    if(isEventPending(%oldie.client.OZS_schedule))
    {
        cancel(%oldie.client.OZS_schedule);
    }
    //Getting Radical Larry's team changes depending on if it's a bot or a human.
    if(%oldie.getClassName() $= "AIPlayer") 
    {
        %oldie_team = %oldie.getDatablock().hType; //If the doctor is a bot, get his hType.
    }
    else
    {
        %oldie_team = %oldie.client.getTeam(); //If the doctor is a human, use "getTeam()"
    }
    //Check if any players are around.
    initContainerRadiusSearch(%oldie.getPosition(), 64, $TypeMasks::PlayerObjectType);
    while((%target = containerSearchNext()) != 0)
    {
        //Mark if enemy players are around and whether or not we're looking at them.
	    %target = %target.getID();
        if(%target.getClassName() $= "AIPlayer")
        {
            %target_team = %target.getDatablock().hType;
        }
        else
        {
            %target_team = %target.client.getTeam();
        }
        if(%target != %oldie && !SCPSL_isAlliedTeam(getMiniGameFromObject(%oldie), %oldie_team, %target_team))
        {
            %nearby = true;
            %spotted = SCPSL_isInFOV(%oldie, %target);
            break;
        }
    }
    //Sneaking: If the oldie isn't moving or is crouched, don't play voice lines and only breathe.
    if((%spotted || %nearby) && !SCPSL_isSpeaking(%oldie) && !%oldie.isCrouched() && %oldie.getVelocity() !$= "0 0 0")
    {
        SCPSL_speak(%oldie, OZS_BreathChase, 2000, 0);
    }
    else if(!SCPSL_isSpeaking(%oldie) && %oldie.voiceLinePlayed !$= "OFN_BreathSearch")
    {
        SCPSL_speak(%oldie, OZS_BreathSearch, 3000, 1);
    }
    %oldie.client.OZS_schedule = schedule($SCPSL::OZS_TickTime, %oldie.getID(), "OZS_loop", %oldie);
}

//
// Main playertype.
//

datablock PlayerData(RadicalLarryArmor : PlayerStandardArmor)
{
    maxForwardSpeed = 8;
	maxBackwardSpeed = 7;
    maxSideSpeed = 7;
    maxDamage = 750;
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
    isSCP = true;

	uiName = "SCP-106";
	showEnergyBar = false;
};
function RadicalLarryArmor::onAdd(%this, %oldie)
{
    if(%this.getName() $= "RadicalLarryArmor")
    {
        //Needs to be used alongside Slayer's team uniform system to look right.
        //Only start the fancy loop if he's in a minigame.
        %minigame = getMiniGameFromObject(%oldie);
        if(isSlayerMinigame(%minigame) && %minigame.Teams.getCount() > 1)
        {
            if(isEventPending(%oldie.client.OZS_schedule))
            {
                cancel(%oldie.client.OZS_schedule);
            }
            %oldie.client.OZS_schedule = schedule(200, %oldie.getID(), "OZS_loop", %oldie);
        }
    }
    parent::onAdd(%this, %oldie);
}
function RadicalLarryArmor::onNewDataBlock(%this, %oldie)
{
    if(%this.getName() $= "RadicalLarryArmor")
    {
        %minigame = getMiniGameFromObject(%oldie);
        if(isSlayerMinigame(%minigame) && %minigame.Teams.getCount() > 1)
        {
            if(isEventPending(%oldie.client.OZS_schedule))
            {
                cancel(%oldie.client.OZS_schedule);
            }
            %oldie.client.OZS_schedule = schedule(200, %oldie.getID(), "OZS_loop", %oldie);
        }
    }
    parent::onNewDataBlock(%this, %oldie);
}
function RadicalLarryArmor::onDisabled(%this, %oldie)
{
    if(%this.getName() $= "RadicalLarryArmor")
    {
        //Make Radical Larry stop breathing if he dies.
        %oldie.stopAudio(2);
        if(isEventPending(%oldie.client.OZS_schedule))
        {
            cancel(%oldie.client.OZS_schedule);
        }
    }
    parent::onDisabled(%this, %oldie);
}
function RadicalLarryArmor::onRemove(%this, %oldie)
{
    ServerPlay3D(SCPSL_getRandomSound(3, 6), %oldie.getPosition());
    %oldie.spawnExplosion(ozsTarProjectile, 1.0);
    schedule(500, %oldie, "delete");
}
function RadicalLarryArmor::onTrigger(%this, %oldie, %slot, %val)
{
    if(%slot == 4 && getWord(%oldie.getVelocity(), 2) == 0)
    {
        if(%val == 1)
        {
            scheduleNoQuota(3000, %oldie.getID(), "OZS_burrow", %oldie);
            OZS_burrowTransition(%oldie);
        }
    }
    else
    {
        parent::onTrigger(%this, %oldie, %slot, %val);
    }
}

//
// Burrowing playertype.
//

datablock PlayerData(BurrowedRadicalLarryArmor : PlayerStandardArmor)
{
    boundingBox = "2.0 2.0 2.0";
	crouchBoundingBox = "2.0 2.0 2.0";
    JumpSound = "";
    jumpForce = 0;
	impactWaterEasy = "";
	impactWaterMedium = "";
	impactWaterHard = "";
    Splash = "";
    exitingWater = "";
    maxForwardSpeed = 8;
	maxBackwardSpeed = 7;
    maxSideSpeed = 7;
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
    canRide = 0;
    maxDamage = 750;
    thirdPersonOnly = true;
    isSCP = true;
    isCloaked = true;

	uiName = "";
	showEnergyBar = false;
};
function BurrowedRadicalLarryArmor::onTrigger(%this, %oldie, %slot, %val)
{
    if(%slot == 0)
    {
        return;
    }
    else if(%slot == 4 && getWord(%oldie.getVelocity(), 2) == 0)
    {
        if(%val == 1)
        {
            scheduleNoQuota(3000, %oldie.getID(), "OZS_unBurrow", %oldie);
            OZS_burrowTransition(%oldie);
        }
    }
    else
    {
        parent::onTrigger(%this, %oldie, %slot, %val);
    }
}
function BurrowedRadicalLarryArmor::Damage(%data, %obj, %sourceObject, %position, %damage, %damageType)
{
    if(%damageType != $DamageType::Suicide)
    {
        return;
    }
    parent::Damage(%data, %obj, %sourceObject, %position, %damage, %damageType);
}

//
// Functions to make Radical Larry burrow into and return from the ground.
//

function OZS_burrowTransition(%oldie)
{
    if(%oldie.getState () $= "Dead")
	{
		return;
	}
    %oldie.setVelocity("0 0 0");
    %client = %oldie.client;
    %oldie.clearTools();
    //Take control away from the player during the transition.
    %client.camera.setOrbitMode(%oldie, %oldie.getTransform(), 0, 10, 0, 1);
    %client.setControlObject(%client.camera);

    ServerPlay3D(SCPSL_getRandomSound("OZS_Decay", 6), %oldie.getPosition());
    %oldie.spawnExplosion(ozsTarProjectile, 1.0);

    %client.schedule(200, "applyUniform");
    %oldie.hideNode(lShoe);
    %oldie.hideNode(rShoe);
    %oldie.hideNode(lPeg);
    %oldie.hideNode(rPeg);
    %oldie.playThread(3, sit);
}

function OZS_burrow(%oldie)
{
    if(%oldie.getState () $= "Dead")
	{
		return;
	}
    if(isEventPending(%oldie.client.OZS_schedule))
    {
        cancel(%oldie.client.OZS_schedule);
    }
    %oldie.isCloaked = 1;
    %oldie.oldPlayerType = %oldie.getDataBlock();
    %oldie.oldDamageLevel = %oldie.getDamageLevel();

    %oldie.ChangeDataBlock(BurrowedRadicalLarryArmor);
    %oldie.setVelocity("0 0 1");
    %oldie.setDamageLevel(%oldie.oldDamageLevel);
    %oldie.setShapeNameDistance(0);
    hideAllNodes(%oldie);
    %oldie.hideNode(headSkin);
    %oldie.client.setControlObject(%oldie);

    if(isPackage(footstepPackage)) //Support for Port and Mr.Noßody's footsteps mod (https://blocklandglass.com/addons/rtb/view.php?id=5205)
    {
        cancel(%oldie.fs_velocityCheckTick());
    }
}

function OZS_unBurrow(%oldie)
{
    if(%oldie.getState () $= "Dead")
	{
		return;
	}
    %client = %oldie.client;
    %oldie.isCloaked = 0;
    %oldie.ChangeDataBlock(%oldie.oldPlayerType);
    %oldie.setVelocity("0 0 1");
    %oldie.setDamageLevel(%oldie.oldDamageLevel);
    %client.applyBodyParts();

    %minigame = getMinigameFromObject(%oldie);
    if(isSlayerMinigame(%minigame))
    {
        %oldie.setShapeNameDistance(%minigame.nameDistance);
    }
    else
    {
        %oldie.setShapeNameDistance(1000);
    }

    %client.setControlObject(%oldie);
    SCPSL_forceEquipTeamItems(%oldie, getMinigameFromObject(%client).Teams.getTeamFromName($SCPSL::OZS_Team));

    %minigame = getMiniGameFromObject(%oldie);
    if(isSlayerMinigame(%minigame) && %minigame.Teams.getCount() > 1)
    {
        OZS_loop(%oldie);
    }

    if(isPackage(footstepPackage))
    {
        %oldie.fs_velocityCheckTick();
    }
}

//
// Package to make burrowed Radical Larries not collide with players or marked bricks while burrowed. Requires the Object Collision DLL: https://gitlab.com/Eagle517/object-collision
//

package Server_SCPSL_OZS_Collision
{
    function onObjectCollisionTest(%obj, %col)
    {
        if(%obj.getType() & $TypeMasks::PlayerObjectType && %col.getType() & $TypeMasks::PlayerObjectType)
        {
            if(%obj.getDataBlock().getName() $= "BurrowedRadicalLarryArmor" || %col.getDataBlock().getName() $= "BurrowedRadicalLarryArmor")
            {
                return false;
            }
        }
        else if(%obj.getType() & $TypeMasks::PlayerObjectType && %col.getType() & $TypeMasks::FxBrickAlwaysObjectType)
        {
            if(%obj.getDataBlock().getName() $= "BurrowedRadicalLarryArmor" || %obj.getDataBlock().getName() $= "RadicalLarryArmor")
            {
                if(%col.getDatablock().category $= "JVS")
                {
                    return false;
                }
                %variableGroup = getVariableGroupFromObject(%col);
                if(isObject(%variableGroup) && %variableGroup.getVariable("Brick", $SCPSL::OZS_noCollideVar, %col))
                {
                    return false;
                }
            }
        }
        parent::onObjectCollisionTest(%obj, %col);
    }
};
activatePackage(Server_SCPSL_OZS_Collision);

//
// Patch to make burrowed Radical Larries not burn.
//

package Server_SCPSL_OZS_Burn
{
    function Player::BurnPlayer(%player, %time)
    {
        if(%player.getDataBlock().getName() $= "BurrowedRadicalLarryArmor")
        {
            return;
        }
        parent::BurnPlayer (%player, %time);
    }
};
activatePackage(Server_SCPSL_OZS_Burn);

//
// Package to make burrowed Radical Larries unable to use their lights.
//

package Server_SCPSL_OZS_Light
{
    function serverCmdLight(%client)
    {
        if(%client.player.getDataBlock.getName() $= "BurrowedRadicalLarryArmor")
        {
            return;
        }
        parent::serverCmdLight(%client);
    }
};
activatePackage(Server_SCPSL_OZS_Light);