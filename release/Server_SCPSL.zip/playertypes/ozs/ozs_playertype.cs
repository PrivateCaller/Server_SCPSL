function OZS_loop(%oldie)
{
    if(%oldie.getState() $= "Dead" || %oldie.getDatablock().getName() !$= "RadicalLarryArmor")
    {
        return;
    }
    //Check if any players are around.
    initContainerRadiusSearch(%oldie.getPosition(), 64, $TypeMasks::PlayerObjectType);
    while((%target = containerSearchNext()) != 0)
    {
        //Mark if enemy players are around and whether or not we're looking at them.
	    %target = %target.getID();
        if(%target != %oldie && !%oldie.client.getTeam().isAlliedTeam(%target.client.getTeam()))
        {
            %nearby = true;
            %spotted = SCPSL_isInFOV(%oldie, %target);
            break;
        }
    }
    //Sneaking: If the oldie isn't moving or is crouched, don't play voice lines and only breathe.
    if((%spotted || %nearby) && !SCPSL_isSpeaking(%oldie) && !%oldie.isCrouched() && %oldie.getVelocity() !$= "0 0 0")
    {
        SCPSL_speak(%oldie, OZS_BreathChase, 2000, 0);
    }
    else if(!SCPSL_isSpeaking(%oldie) && %oldie.voiceLinePlayed !$= "OFN_BreathSearch")
    {
        SCPSL_speak(%oldie, OZS_BreathSearch, 3000, 1);
    }
    %oldie.client.OZS_schedule = schedule($SCPSL::OZS_TickTime, %oldie.getID(), "OZS_loop", %oldie);
}

//
// Main playertype.
//

datablock PlayerData(RadicalLarryArmor : PlayerStandardArmor)
{
    maxForwardSpeed = 8;
	maxBackwardSpeed = 7;
    maxSideSpeed = 7;
    maxDamage = 750;
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
    isSCP = true;

	uiName = "SCP-106";
	showEnergyBar = false;
};
function RadicalLarryArmor::onAdd(%this, %oldie)
{
    if(%this.getName() $= "RadicalLarryArmor")
    {
        //Needs to be used alongside Slayer's team uniform system to look right.
        //Only start the fancy loop if he's in a minigame.
        %minigame = getMiniGameFromObject(%oldie);
        if(isSlayerMinigame(%minigame) && %minigame.Teams.getCount() > 1)
        {
            OZS_loop(%oldie);
        }
    }
    parent::onAdd(%this, %oldie);
}
function RadicalLarryArmor::onNewDataBlock(%this, %oldie)
{
    if(%this.getName() $= "RadicalLarryArmor")
    {
        %minigame = getMiniGameFromObject(%oldie);
        if(isSlayerMinigame(%minigame) && %minigame.Teams.getCount() > 1)
        {
            OFN_loop(%oldie);
        }
    }
    parent::onNewDataBlock(%this, %oldie);
}
function RadicalLarryArmor::onDisabled(%this, %oldie)
{
    if(%this.getName() $= "RadicalLarryArmor")
    {
        //Make Radical Larry stop breathing if he dies.
        %oldie.stopAudio(2);
        if(isEventPending(%oldie.client.OZS_schedule))
        {
            cancel(%oldie.client.OZS_schedule);
        }
    }
    parent::onDisabled(%this, %oldie);
}
function RadicalLarryArmor::onRemove(%this, %oldie)
{
    ServerPlay3D(SCPSL_getRandomSound(3, 6), %oldie.getPosition());
    %oldie.spawnExplosion(ozsTarProjectile, 1.0);
    schedule(500, %oldie, "delete");
}
function RadicalLarryArmor::onTrigger(%this, %oldie, %slot, %val)
{
    if(%slot == 4 && %oldie.getVelocity() $= "0 0 0")
    {
        if(%val == 1)
        {
            OZS_burrowTransition(%oldie);
            scheduleNoQuota(3000, %oldie.getID(), "OZS_burrow", %oldie);
        }
    }
    else
    {
        parent::onTrigger(%this, %oldie, %slot, %val);
    }
}

//
// Burrowing playertype.
//

datablock PlayerData(BurrowedRadicalLarryArmor : PlayerStandardArmor)
{
    boundingBox = "1.25 1.25 0.2";
	crouchBoundingBox = "1.25 1.25 0.2";
    JumpSound = "";
    jumpForce = 0;
	impactWaterEasy = "";
	impactWaterMedium = "";
	impactWaterHard = "";
    Splash = "";
    exitingWater = "";
    maxForwardSpeed = 8;
	maxBackwardSpeed = 7;
    maxSideSpeed = 7;
	minJetEnergy = 0;
	jetEnergyDrain = 0;
	canJet = 0;
    canRide = 0;
    maxDamage = 750;
    thirdPersonOnly = true;
    isSCP = true;
    isCloaked = true;

	uiName = "";
	showEnergyBar = false;
};
function BurrowedRadicalLarryArmor::onTrigger(%this, %oldie, %slot, %val)
{
    if(%slot == 0)
    {
        return;
    }
    else if(%slot == 4 && %oldie.getVelocity() $= "0 0 0")
    {
        if(%val == 1)
        {
            OZS_burrowTransition(%oldie);
            scheduleNoQuota(3000, %oldie.getID(), "OZS_unBurrow", %oldie);
        }
    }
    else
    {
        parent::onTrigger(%this, %oldie, %slot, %val);
    }
}

//
// Functions to make Radical Larry burrow into and return from the ground.
//

function OZS_burrowTransition(%oldie)
{
    if(%oldie.getState () $= "Dead")
	{
		return;
	}
    %client = %oldie.client;
    %oldie.clearTools();
    //Take control away from the player during the transition.
    %client.camera.setOrbitMode(%oldie, %oldie.getTransform(), 0, 10, 0, 1);
    %client.setControlObject(%client.camera);

    ServerPlay3D(SCPSL_getRandomSound("OZS_Decay", 6), %oldie.getPosition());
    %oldie.spawnExplosion(ozsTarProjectile, 1.0);

    %client.schedule(200, "applyUniform");
    %oldie.hideNode(lShoe);
    %oldie.hideNode(rShoe);
    %oldie.hideNode(lPeg);
    %oldie.hideNode(rPeg);
    %oldie.playThread(3, sit);

    %oldie.setVelocity("0 0 0");
}

function OZS_burrow(%oldie)
{
    if(%oldie.getState () $= "Dead")
	{
		return;
	}
    if(isEventPending(%oldie.client.OZS_schedule))
    {
        cancel(%oldie.client.OZS_schedule);
    }
    %oldie.isCloaked = 1;
    %oldie.oldPlayerType = %oldie.getDataBlock();
    %oldie.oldDamageLevel = %oldie.getDamageLevel();

    %oldie.ChangeDataBlock(BurrowedRadicalLarryArmor);
    %oldie.setVelocity("0 0 1");
    %oldie.setDamageLevel(%oldie.oldDamageLevel);
    hideAllNodes(%oldie);
    %oldie.hideNode(headSkin);
    %oldie.client.setControlObject(%oldie);
}

function OZS_unBurrow(%oldie)
{
    if(%oldie.getState () $= "Dead")
	{
		return;
	}
    %client = %oldie.client;
    %oldie.isCloaked = 0;
    %oldie.ChangeDataBlock(%oldie.oldPlayerType);
    %oldie.setVelocity("0 0 1");
    %oldie.setDamageLevel(%oldie.oldDamageLevel);
    %client.applyBodyParts();

    %client.setControlObject(%oldie);
    SCPSL_forceEquipTeamItems(%oldie, getMinigameFromObject(%client).Teams.getTeamFromName($SCPSL::OZS_Team));

    %minigame = getMiniGameFromObject(%oldie);
    if(isSlayerMinigame(%minigame) && %minigame.Teams.getCount() > 1)
    {
        OZS_loop(%oldie);
    }
}

//
// Package to make burrowed Radical Larries not collide with players or marked bricks.
// Requires the Object Collision DLL: https://gitlab.com/Eagle517/object-collision
//

function onObjectCollisionTest(%obj, %col)
{
    if(%obj.getType() & $TypeMasks::PlayerObjectType && %col.getType() & $TypeMasks::PlayerObjectType)
    {
        if(%obj.getDataBlock().getName() $= "BurrowedRadicalLarryArmor" || %col.getDataBlock().getName() $= "BurrowedRadicalLarryArmor")
        {
            return false;
        }
    }
    else if(%obj.getType() & $TypeMasks::FxBrickAlwaysObjectType && %col.getType() & $TypeMasks::PlayerObjectType)
    {
        if(%obj.getDataBlock().category $= "JVS")
        {
            return false;
        }
        %variableGroup = getVariableGroupFromObject(%obj);
        if(%variableGroup.getVariable("Brick", $SCPSL::OZS_noCollideVar, %col))
        {
            return false;
        }
    }
    return true;
}