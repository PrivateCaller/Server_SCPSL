datablock AudioProfile(OZS_BreathSearch)
{
	fileName = "./sounds/OZS_BreathSearch.wav";
	description = AudioClosestLooping3d;
	preload = 0;
};
datablock AudioProfile(OZS_BreathChase)
{
	fileName = "./sounds/OZS_BreathChase.wav";
	description = AudioCloseLooping3d;
	preload = 0;
};

datablock AudioProfile(OZS_Kidnap1)
{
	fileName = "./sounds/OZS_Kidnap1.wav";
	description = AudioClose3d;
	preload = 0;
};
datablock AudioProfile(OZS_Kidnap2 : OZS_Kidnap1)
{
	filename = "./sounds/OZS_Kidnap2.wav";
};
datablock AudioProfile(OZS_Kidnap3 : OZS_Kidnap1)
{
	filename = "./sounds/OZS_Kidnap3.wav";
};

datablock AudioProfile(OZS_Decay1 : OZS_Kidnap1)
{
	filename = "./sounds/OZS_Decay1.wav";
};
datablock AudioProfile(OZS_Decay2 : OZS_Kidnap1)
{
	filename = "./sounds/OZS_Decay2.wav";
};
datablock AudioProfile(OZS_Decay3 : OZS_Kidnap1)
{
	filename = "./sounds/OZS_Decay3.wav";
};
datablock AudioProfile(OZS_Decay4 : OZS_Kidnap1)
{
	filename = "./sounds/OZS_Decay4.wav";
};
datablock AudioProfile(OZS_Decay5 : OZS_Kidnap1)
{
	filename = "./sounds/OZS_Decay5.wav";
};
datablock AudioProfile(OZS_Decay6 : OZS_Kidnap1)
{
	filename = "./sounds/OZS_Decay6.wav";
};