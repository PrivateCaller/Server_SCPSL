//Ripped from Rotondo's holebot "hFOVCheck" function, then minimized into oblivian for speed purposes. Last function was slow.
function SCPSL_isInFOV(%player, %target)
{	
	return vectorDot(%player.getEyeVector(), vectorNormalize(vectorSub(%target.getPosition(), %player.getPosition()))) >= 0.7;
}
//All of the sounds used in this mod are 8-bit 22050Hz Mono sounds, so estimating their length based on file size is actually feasible and surprisingly accurate.
function SCPSL_estimateSoundDuration(%sound)
{
    //Returns duration in milliseconds.
    return getFileLength(%sound.filename) / 22.05;
}