//Creating this allows the function to be packaged. Requires the Object Collision DLL to do anything: https://gitlab.com/Eagle517/object-collision
function onObjectCollisionTest(%obj, %col)
{
    return true;
}
//Prevents SCPs from picking up items.
package Server_SCPSL_SCP_NoItemPickup
{
	function ShapeBase::pickup(%obj, %item)
	{
		if(!%obj.getDataBlock().isSCP)
		{
            parent::pickup(%obj, %item);
		}
	}
    function Player::addItem(%player, %image, %client)
	{
		if(!%player.getDataBlock().isSCP)
		{
			parent::addItem(%player, %image, %client);
		}
	}
};
activatePackage(Server_SCPSL_SCP_NoItemPickup);
//Ripped from Rotondo's holebot "hFOVCheck" function, then minimized into oblivian for speed purposes. Last function was slow.
function SCPSL_isInFOV(%player, %target)
{	
	return vectorDot(%player.getEyeVector(), vectorNormalize(vectorSub(%target.getPosition(), %player.getPosition()))) >= 0.7;
}
//All of the sounds used in this mod are 8-bit 16000kHz Mono sounds, so estimating their length based on file size is feasible and surprisingly accurate.
function SCPSL_estimateSoundDuration(%sound)
{
    //Returns duration in milliseconds.
    return getFileLength(%sound.filename) / 16;
}
//Returns a ID (if available) from a prefix and appended random number of specified ceiling.
function SCPSL_getRandomSound(%prefix, %highestNumber)
{
    %randomNumber = getRandom(1, %highestNumber); //Didn't work without seperating this from the return.
    return NameToID(%prefix @ %randomNumber);
}
//Make a player play a 3D sound, as well as mark when it will end.
function SCPSL_speak(%player, %voiceLine, %pause, %unimportant)
{
    %player.stopAudio(2);
    %player.playAudio(2, %voiceLine);
    %player.voiceLinePlayed = "" @ %voiceLine;
    if(%unimportant)
    {
        %player.willFinishSpeaking = 0;
    }
    else
    {
        %player.willFinishSpeaking = (getSimTime() + (SCPSL_estimateSoundDuration(%voiceLine) + %pause));
    }
    return %player.willFinishSpeaking;
}
//Check whether or not the 3D sound is playing on someone, as well as whether or
function SCPSL_isSpeaking(%player)
{
    if(getSimTime() > %player.willFinishSpeaking)
    {
        return 0;
    }
    else
    {
        return 1;
    }
}
//Forces client to equip items from a Slayer team.
function SCPSL_forceEquipTeamItems(%player, %team)
{
	for(%i = 0; %i < %player.getDatablock().maxTools; %i++)
    {
		%player.client.forceEquip(%i, %team.startEquip[%i]);
    }
    %player.updateArm(0);
    %player.unMountImage(0);
}
//Copy of Slayer's "isAlliedTeam" function, but with holebot support.
function SCPSL_isAlliedTeam(%minigame, %obj_team, %target_team)
{
    if(!isObject(%minigame))
    {
        return;
    }

    if(%obj_team $= %target_team)
    {
        return true;
    }
    else if(isSlayerMinigame(%minigame))
    {
        if(%minigame.teams_allySameColors && %obj_team.color $= %target_team.color)
        {
            return true;
        }
    }
    else
    {
        return false;
    }
}