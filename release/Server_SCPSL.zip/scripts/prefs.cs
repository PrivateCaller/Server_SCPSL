function SCPSL_upToDate()
{
	//Read the first line of the variable file to determine version, then check it against the global variable created by Support_Updater.
	//(Probably doesn't work, can't get Support_Updater to push out an update.)
	%file = new fileObject();
	%file.openForRead("config/server/SCPSL/variables.cs");
	%version = %file.readLine();
	%file.close();
	%file.delete();
	if(%version $= $SCPSL::version)
		return 1;
	else
		echo("SCPSL: New update, resetting saved variables.");
		return 0;
}

function SCPSL_savePreferencesToFile()
{
	//Used to save Preferences to a custom file if the server host doesn't have Glass.
	%writeString = $SCPSL::version NL $SCPSL::OFN_Team NL $SCPSL::OFN_TickTime NL $SCPSL::OZS_Team NL $SCPSL::OZS_LairVar NL $SCPSL::OZS_TickTime NL $SCPSL::OZS_BurrowTime NL $SCPSL::OZS_noCollideVar NL $SCPSL::surfaceVar NL $SCPSL::lczVar NL $SCPSL::ZombiesInfect NL $SCPSL::InfectTumble;

	%file = new fileObject();
	%file.openForWrite("config/server/SCPSL/variables.cs");
	%file.writeLine(%writeString);
	%file.close();
	%file.delete();

	if(!isFile("config/server/SCPSL/variables.cs")) //Just to avoid confusion when the file is created.
		echo("SCPSL: Config file didn't exist. Made a new one.");
	else
		echo("SCPSL: Preferences saved.");
}

function SCPSL_readPreferencesFromFile()
{
	//Read the data and create variables line-by-line using it.
	%file = new fileObject();
	%file.openForRead("config/server/SCPSL/variables.cs");
	while(!%file.isEOF())
	{
		//readLine() automatically moves to the next line down.
		%file.readLine(); //Skip the version number, as this is hardcoded.
		$SCPSL::OFN_Team = %file.readLine();
		$SCPSL::OFN_TickTime = %file.readLine();
		$SCPSL::OZS_Team = %file.readLine();
		$SCPSL::OZS_LairVar = %file.readLine();
		$SCPSL::OZS_TickTime = %file.readLine();
		$SCPSL::OZS_BurrowTime = %file.readLine();
		$SCPSL::OZS_noCollideVar = %file.readLine();
		$SCPSL::surfaceVar = %file.readLine();
		$SCPSL::lczVar = %file.readLine();
		$SCPSL::ZombiesInfect = %file.readLine();
		$SCPSL::InfectTumble = %file.readLine();
	}
	%file.close();
	%file.delete();
	echo("SCPSL: Preferences loaded from config file.");
}

package SCPSL_glasslessPreferenceSaving
{
    function destroyServer()
    {
		//If the host uses the "Disconnect" button. Packages get deactivated after the server shuts down, so this is needed.
		SCPSL_savePreferencesToFile();
        parent::destroyServer();
    }
	function onExit()
	{
		//If the host uses the "Quit" button.
		SCPSL_savePreferencesToFile();
		parent::onExit();
	}
	function quit()
	{
		//If the host enters "quit();" into the console.
		SCPSL_savePreferencesToFile();
		parent::quit();
	}
};
activatepackage(SCPSL_glasslessPreferenceSaving);
