$error = forceRequiredAddOn("Weapon_Rocket_Launcher");
if($error == $Error::AddOn_NotFound)
{
	error("ERROR: Server_SCPSL - Required add-on Weapon_Rocket_Launcher not found! 'killUndergroundPlayers' event cannot be used.");
	return;
}
$error = forceRequiredAddOn("Event_Variables");
if($error == $Error::AddOn_NotFound)
{
	error("ERROR: Server_SCPSL - Required add-on Event_Variables not found! Kill events cannot be used.");
	return;
}

function MiniGameSO::killUndergroundPlayers(%mini)
{
    //"GetVariableGroupFromObject.getVariable" is a check for VCE variables.
    if(%mini.numMembers <= 0 || !isSlayerMinigame(%mini) || %mini.Teams.getCount() < 1)
    {
        warn("MiniGameSO::killUndergroundPlayers | Conditions not met.");
        return;
    }
    for(%i = 0; %i < %mini.numMembers; %i++)
    {
        %player = %mini.member[%i].player;
        %variableGroup = getVariableGroupFromObject(%player);
        if(!isObject(%variableGroup))
        {
            error("MiniGameSO::killUndergroundPlayers | Variable group not found on player" SPC %player.client.getBLID() SPC ".");
        }
        if(!%variableGroup.getVariable("Player", $SCPSL::surfaceVar, %player))
        {
            %player.spawnExplosion(rocketLauncherProjectile, 3.0);
            %player.schedule(50, "kill");
        }
    }
}
registerOutputEvent ("MiniGame", "killUndergroundPlayers", "");

function MiniGameSO::killLowContainZonePlayers(%mini)
{
    if(%mini.numMembers <= 0 || !isSlayerMinigame(%mini) || %mini.Teams.getCount() < 1)
    {
        warn("MiniGameSO::killLowContainZonePlayers | Conditions not met.");
        return;
    }
    for(%i = 0; %i < %mini.numMembers; %i++)
    {
        %player = %mini.member[%i].player;
        %variableGroup = getVariableGroupFromObject(%player);
        if(!isObject(%variableGroup))
        {
            error("MiniGameSO::killLowContainZonePlayers | Variable group not found on player" SPC %player.client.getBLID() SPC ".");
        }
        if(%variableGroup.getVariable("Player", $SCPSL::lczVar, %player))
        {
            %player.schedule(50, "kill");
        }
    }
}
registerOutputEvent ("MiniGame", "killLowContainZonePlayers", "");

function MiniGameSO::kill106(%mini)
{
    if(%mini.numMembers <= 0 || !isSlayerMinigame(%mini) || %mini.Teams.getCount() < 1)
    {
        warn("MiniGameSO::kill106 | Conditions not met.");
        return;
    }
    %oldie_team = %mini.Teams.getTeamFromName($SCPSL::OZS_Team);
    if(!%oldie_team)
    {
        error("MiniGameSO::kill106 | 106 team not found.");
        return;
    }
    for(%i = 0; %i < %mini.numMembers; %i++)
    {
        %player = %mini.member[%i].player;
        %variableGroup = getVariableGroupFromObject(%player);
        if(!isObject(%variableGroup))
        {
            error("MiniGameSO::kill106 | Variable group not found on player" SPC %player.client.getBLID() SPC ".");
        }
        if(%player.client.getTeam() $= %oldie_team)
        {
            %player.schedule(50, "kill");
        }
    }
}
registerOutputEvent ("MiniGame", "kill106", "");