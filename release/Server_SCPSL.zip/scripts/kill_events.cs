$error = forceRequiredAddOn("Weapon_Rocket_Launcher");
if($error == $Error::AddOn_NotFound)
{
	error("ERROR: Server_SCPSL - Required add-on Weapon_Rocket_Launcher not found! 'killUndergroundPlayers' event cannot be used.");
	return;
}
$error = forceRequiredAddOn("Event_Variables");
if($error == $Error::AddOn_NotFound)
{
	error("ERROR: Server_SCPSL - Required add-on Event_Variables not found! Kill events cannot be used.");
	return;
}

function MiniGameSO::killUndergroundPlayers(%mini)
{
    if(%mini.numMembers <= 0)
    {
        return;
    }
    for(%i = 0; %i <= %mini.numMembers; %i++)
    {
        %player = %mini.member[%i].player;
        //"GetVariableGroupFromObject.getVariable" is a check for VCE variables.
        if(!getVariableGroupFromObject(%player).getVariable("Player", $SCPSL::surfaceVar, %player))
        {
            %player.spawnExplosion(rocketLauncherProjectile, 3, %player.client);
            %player.schedule(50, "kill");
        }
    }
}
registerOutputEvent ("MiniGame", "killUndergroundPlayers", "");

function MiniGameSO::killLowContainZonePlayers(%mini)
{
    if(%mini.numMembers <= 0)
    {
        return;
    }
    for(%i = 0; %i <= %mini.numMembers; %i++)
    {
        %player = %mini.member[%i].player;
        //"GetVariableGroupFromObject.getVariable" is a check for VCE variables.
        if(!getVariableGroupFromObject(%player).getVariable("Player", $SCPSL::lczVar, %player))
        {
            %player.kill();
        }
    }
}
registerOutputEvent ("MiniGame", "killLowContainZonePlayers", "");